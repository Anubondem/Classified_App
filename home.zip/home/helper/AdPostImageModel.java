package com.scriptsbundle.adforest.home.helper;

public class AdPostImageModel {
    private String img_size;
    private String img_message;
    private boolean dim_is_show;
    private String dim_width;
    private String dim_height;
    private String dim_height_message;

    public String getImg_size() {
        return img_size;
    }

    public void setImg_size(String img_size) {
        this.img_size = img_size;
    }

    public String getImg_message() {
        return img_message;
    }

    public void setImg_message(String img_message) {
        this.img_message = img_message;
    }

    public boolean getDim_is_show() {
        return dim_is_show;
    }

    public void setDim_is_show(boolean dim_is_show) {
        this.dim_is_show = dim_is_show;
    }

    public String getDim_width() {
        return dim_width;
    }

    public void setDim_width(String dim_width) {
        this.dim_width = dim_width;
    }

    public String getDim_height() {
        return dim_height;
    }

    public void setDim_height(String dim_height) {
        this.dim_height = dim_height;
    }

    public String getDim_height_message() {
        return dim_height_message;
    }

    public void setDim_height_message(String dim_height_message) {
        this.dim_height_message = dim_height_message;
    }
}
