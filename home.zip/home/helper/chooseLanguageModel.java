package com.scriptsbundle.adforest.home.helper;

public class chooseLanguageModel {


    private String title;
    private String languageCode;

    public String getNodataMessage() {
        return NodataMessage;
    }

    public void setNodataMessage(String nodataMessage) {
        NodataMessage = nodataMessage;
    }

    private String NodataMessage;

    public String getTitle2() {
        return title2;
    }

    public void setTitle2(CharSequence concat, String title2) {
        this.title2 = title2;
    }

    private String title2;

    public String getImage() {
        return image;
    }

    public void setImage(String image) {
        this.image = image;
    }

    public String getLanguageCode() {
        return languageCode;
    }

    public void setLanguageCode(String languageCode) {
        this.languageCode = languageCode;
    }

    private String image;

                public chooseLanguageModel() {
                }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }


}
