package com.scriptsbundle.adforest.home.helper;

public class CalanderTextModel {
    private String btn_ok;
    private String btn_cancel;
    private String title;

    public String getBtn_ok() {
        return btn_ok;
    }

    public void setBtn_ok(String btn_ok) {
        this.btn_ok = btn_ok;
    }

    public String getBtn_cancel() {
        return btn_cancel;
    }

    public void setBtn_cancel(String btn_cancel) {
        this.btn_cancel = btn_cancel;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }
}
